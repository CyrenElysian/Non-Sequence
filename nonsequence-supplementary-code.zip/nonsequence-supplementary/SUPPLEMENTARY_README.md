# Non-Sequence — Supplementary Code and Data Package

This archive supports reproducibility review for the accompanying AAAI submission. It contains source code, prompts, configuration manifests, datasets, and published prediction artifacts for the CtrlScript graph-generation benchmark and the Loop Termination Judgment (LTJ) data pipeline.

## Requirements

- Python 3.10 or newer
- Internet access only for model-assisted stages (API calls)

## Quick start

```bash
python -m venv .venv
# Linux/macOS: source .venv/bin/activate
# Windows PowerShell: .venv\Scripts\Activate.ps1
pip install -r requirements.txt
pip install -e .
```

Copy `.env.example` to `.env` and set API credentials before running any LLM stage. Never commit real keys.

## Verify published CtrlScript numbers (no API required)

The main paper reports aggregate metrics on all 1,061 CtrlScript records. Reviewers can recompute them offline:

```bash
nonsequence-evaluate \
  --predictions results/ctrlscript/results_v4-flash.json \
  --dataset data/ctrlscript/CtrlScript_with_stats.json \
  --output results/ctrlscript/eval_summary_v4-flash_recomputed.json

nonsequence-evaluate \
  --predictions results/ctrlscript/results_v4-pro.json \
  --dataset data/ctrlscript/CtrlScript_with_stats.json \
  --output results/ctrlscript/eval_summary_v4-pro_recomputed.json
```

Reference summaries shipped with this package:

- `results/ctrlscript/eval_summary_v4-flash.json`
- `results/ctrlscript/eval_summary_v4-pro.json`

Expected overall joint exact match (from those files): Flash 43.83% (465/1,061); Pro 47.13% (500/1,061).

## Full graph-generation pipeline

Suggested order (see `docs/REPRODUCIBILITY.md` for details):

```bash
nonsequence-cut
nonsequence-convert
nonsequence-correct-edges --model deepseek-v4-flash
nonsequence-select-loop --model deepseek-v4-flash
nonsequence-check --model deepseek-v4-pro
nonsequence-count-structure
nonsequence-predict --model deepseek-v4-flash
nonsequence-evaluate
```

Preprocessing and evaluation do not require an API key. Model-assisted stages use the environment variable named by `--api-key-env` (default: `DEEPSEEK_API_KEY`).

## LTJ pipeline

```bash
nonsequence-ltj-filter-sequences
nonsequence-ltj-filter-loops
nonsequence-ltj-filter-quality
nonsequence-ltj-generate
nonsequence-ltj-judge
```

Intermediate LTJ artifacts are under `data/ltj/`. No public LTJ evaluation summary is included in this release.

## Package contents

| Path | Description |
|------|-------------|
| `src/nonsequence/` | All pipeline modules and CLI entry points |
| `prompts/` | Prompt templates for LLM-assisted stages |
| `configs/` | Example model, task, and run manifests |
| `data/ctrlscript/` | Final CtrlScript dataset (1,061 records) |
| `data/raw/proscript/` | Source ProScript splits used in dataset construction |
| `data/ltj/` | LTJ funnel and description artifacts |
| `data/interim/ctrlscript/` | Example intermediate construction artifacts |
| `results/ctrlscript/` | Saved predictions and evaluation summaries |
| `docs/` | Pipeline, dataset, evaluation, and reproducibility notes |

## Data provenance

- **ProScript** is the upstream procedural script corpus. Users are responsible for complying with the original ProScript terms when reusing or redistributing raw splits.
- **CtrlScript** is the constructed benchmark distributed in this package.
- Model identifiers such as `deepseek-v4-flash` and `deepseek-v4-pro` are convenience labels; hosted models may change across provider revisions.

## CLI reference

Every stage exposes `--help`, for example:

```bash
nonsequence-predict --help
nonsequence-evaluate --help
```

## Limitations

This is a research artifact, not a production workflow engine. LLM-assisted annotations may contain residual errors, and exact graph match penalizes valid alternative orderings. See `README.md` and `docs/DATASET_CARD.md` for full limitations.
