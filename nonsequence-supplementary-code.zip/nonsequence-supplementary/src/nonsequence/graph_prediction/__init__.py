"""Graph-prediction inference commands."""
